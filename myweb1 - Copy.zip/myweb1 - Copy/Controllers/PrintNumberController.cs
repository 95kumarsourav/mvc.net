﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace myweb1.Controllers
{
    public class PrintNumberController : Controller
    {
        // GET: PrintNumber
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult PrimeNumber(string id)
        {
            ViewData["no"] = id;
            return View();

        }


        public ActionResult Fibonacci(string id)
        {

            ViewData["no"] = id;
            return View();


        }


    }
}